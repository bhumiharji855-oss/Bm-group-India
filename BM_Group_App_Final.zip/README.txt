BM GROUP OF INDIA - MINE ULTRA WASH  (App package)
====================================================

FILES
  index.html      -> poora app (ek hi file me sab kuch)
  manifest.json   -> install settings (app naam, icon, full-screen)
  icon-192.png    -> app icon (chhota)
  icon-512.png    -> app icon (bada)

GITHUB PAR UPLOAD KAISE KAREIN
  1. github.com/bhumiharji855-oss/Bm-group-India/upload/main kholein
  2. Ye saari 4 files ek saath select karein
  3. Neeche "Commit changes" dabayein
  4. 1-2 minute baad link refresh karein

APP KA LINK
  https://bhumiharji855-oss.github.io/Bm-group-India/

PHONE ME INSTALL
  1. Link Chrome me kholein
  2. "Install" button dabayein -> Install
  3. Home screen par BM Group ka icon -> full screen app

OWNER PANEL
  BM logo par 5 baar tap karein -> PIN 878024

ORDERS
  Har order seedha WhatsApp (8227010433) par aata hai
  UPI payment: QR code checkout me lagta hai
